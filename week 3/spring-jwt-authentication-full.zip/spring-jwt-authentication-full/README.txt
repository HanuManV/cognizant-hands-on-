Cognizant Digital Nurture JWT project skeleton.

Included:
- SpringLearnApplication.java
- SecurityConfig.java
- AuthenticationController.java
- JwtTokenUtil.java
- JwtRequestFilter.java
- JwtAuthenticationEntryPoint.java
- AppUserDetailsService.java
- AuthenticationResponse.java
- application.properties
- logback.xml
- pom.xml

Import as a Maven project in Eclipse/STS.
