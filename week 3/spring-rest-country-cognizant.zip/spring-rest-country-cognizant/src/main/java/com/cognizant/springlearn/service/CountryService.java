package com.cognizant.springlearn.service;
import com.cognizant.springlearn.Country;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
@Service
public class CountryService{
private static final Logger LOGGER=LoggerFactory.getLogger(CountryService.class);
public Country getCountry(){
LOGGER.debug("START");
ApplicationContext context=new ClassPathXmlApplicationContext("country.xml");
Country country=context.getBean("country",Country.class);
LOGGER.debug("END");
return country;
}
}